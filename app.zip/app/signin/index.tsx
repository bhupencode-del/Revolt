import SignInScreen from "../../src/screens/SignInScreen";

export default function SignIn() {
  return <SignInScreen />;
}
