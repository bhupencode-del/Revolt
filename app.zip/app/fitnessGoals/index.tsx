import FitnessGoalsScreen from "../../src/screens/FitnessGoalsScreen";

export default function FitnessGoals() {
  return <FitnessGoalsScreen />;
}


