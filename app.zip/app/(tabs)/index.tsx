import SplashScreenComponent from "../../src/screens/SplashScreen";

export default function Index() {
  return <SplashScreenComponent />;
}
