import OnboardingScreen from "../../src/screens/OnboardingScreen";

export default OnboardingScreen;

