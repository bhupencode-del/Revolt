import React from "react";
import AccountSetupScreen from "../../src/screens/AccountSetup";

const AccountSetupPage = () => {
  return <AccountSetupScreen />;
};

export default AccountSetupPage;
