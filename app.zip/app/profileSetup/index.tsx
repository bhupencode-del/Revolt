import ProfileSetupScreen from "../../src/screens/ProfileSetupScreen";

export default function ProfileSetup() {
  return <ProfileSetupScreen />;
}
