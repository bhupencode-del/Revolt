import FitnessLevelScreen from "../../src/screens/FitnessLevelScreen";

export default function fitnessLevel() {
  return <FitnessLevelScreen />;
}