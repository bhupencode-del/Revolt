import MedicalConditionsScreen from "../../src/screens/MedicalConditionsScreen";

export default function MedicalConditions() {
  return <MedicalConditionsScreen />;
}
