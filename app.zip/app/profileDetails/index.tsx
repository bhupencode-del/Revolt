import ProfileDetailsScreen from "../../src/screens/ProfileDetailsScreen";

export default function profileDetails() {
  return <ProfileDetailsScreen />;
}